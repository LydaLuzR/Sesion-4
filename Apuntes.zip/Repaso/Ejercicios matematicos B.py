#Para hacer una suma o cualquier operación básica basta con poner
print(5+5)
##Multiplicación
print(5*5)
#Para saber el resultado de una división
print(5/5)
##Para saber el consciente de una división
print(25//5)
##Para saber el resto/lo que sobra de la división
print(25%5)
#Potencia
print(2**4)
#Sigue las reglas matematicas primero haciendo las multiplicaciones
print(5+5*2)
#Para sacar raiz cuadrada siempre se utiliza
import math
x= 25
y= math.sqrt(x)
print(y)
