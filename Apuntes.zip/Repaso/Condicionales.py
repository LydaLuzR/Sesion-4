Edad=int(input("Por favor escriba su edad "))
if Edad > 17:
    print("Usted es mayor de edad")
else:
    print("Usted es menor de edad")  

Numero=int(input("Escriba un número "))
if Numero>10:
    print("Ese número es mayor a 10")
elif Numero == 10:
    print("Es igual a 10")
else:
    print("Es menor a 10") 