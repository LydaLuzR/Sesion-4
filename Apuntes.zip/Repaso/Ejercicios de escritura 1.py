
N1=int(input("Escriba un número "))
    ##Input sirve para mostrar el número e interactuar con él
N2=int(input("Escriba otro número "))
    ###Para la suma siempre tengo que definir el tipo de variable que voy a aplicar identificandola como un número
    ##Ejemplo diciendo si es Int (Entero) o Float(Decimal) ya que si no lo hago da error
Total=int(N1+N2)
print(Total)

##ANOTACIÓN ÚTIL##
    ##Input("") para pedirle al usuario que introduzca datos.
    ##Int() con datos o variables dentro de parentesis para convertirlo en número entero.
    ##Str() para convertir números tanto decimales como enteros a strings.

#Para combertir números de uno a otro
N1=float(input("Escriba un número "))
N2=float(input("Escriba otro número "))
Total=int(N1+N2)
print(Total)
    #Basta solo con colocar el valor al que se quiera cambiar en el total o donde se va a mostar


NumeroD= 5.4
print(str(NumeroD))
    #Str cambia el valor de número ya sea Int o Float a texto aunque no lo parezca
